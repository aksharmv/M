package com.example.lab2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button btn;
    ProgressBar progressBar;
    TextView textView;
    int progressStatus;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn=findViewById(R.id.alert_btn);
        progressBar=findViewById(R.id.progressBar);
        textView=findViewById(R.id.value);



        Handler handler=new Handler();

        new Thread(new Runnable() {
            @Override
            public void run() {
                while (progressStatus<100){
                    progressStatus+=1;
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            progressBar.setProgress(progressStatus);
                            textView.setText(progressStatus+"%");

                        }
                    });
                    try{
                        Thread.sleep(200);
                    }
                    catch (InterruptedException e){
                        e.printStackTrace();
                    }
                }
            }
        }).start();



        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Alert!");
                builder.setPositiveButton("Accept",(dialog, which) ->
                {
                    finish();
                });
                builder.setNegativeButton("Reject",(dialog, which) ->
                {
                   dialog.cancel();
                });
                builder.setNeutralButton("cancel",(dialog, which) ->
                {
                    dialog.cancel();
                });
                builder.setMessage("Are you sure to exit");
                builder.setCancelable(false);
                builder.setIcon(R.drawable.alert);
                AlertDialog alertDialog=builder.create();
                alertDialog.show();
            }
        });

    }
}