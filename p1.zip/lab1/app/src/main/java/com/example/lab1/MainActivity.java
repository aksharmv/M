package com.example.lab1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CalendarView;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.Switch;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {
    Switch state;
    ImageButton imageButton;
    ConstraintLayout layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        state=findViewById(R.id.switch1);
        imageButton=findViewById(R.id.img_btn);
        layout=findViewById(R.id.clayout);

        state.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    imageButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Snackbar.make(v,"Button is clicked",Snackbar.LENGTH_LONG).show();
                        }
                    });
                    imageButton.setEnabled(true);
                    state.setText("Enabled");
                }
                else{
                    imageButton.setEnabled(false);
                    state.setText("Disabled");
                }
            }
        });
        CalendarView calendarView=new CalendarView(getApplicationContext());
        ConstraintLayout.LayoutParams params=new ConstraintLayout.LayoutParams(
                ConstraintLayout.LayoutParams.MATCH_PARENT,
                ConstraintLayout.LayoutParams.MATCH_PARENT
        );
        layout.addView(calendarView,params);
    }
}